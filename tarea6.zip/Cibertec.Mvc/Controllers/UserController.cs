﻿using Cibertec.Models;
using Cibertec.Mvc.ActionFilters;
using Cibertec.UnitOfWork;
using log4net;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Cibertec.Mvc.Controllers
{
    [Authorize(Roles = "Admin")]
    [ErrorActionFilter]
    public class UserController : BaseController
    {
        public UserController(ILog log, IUnitOfWork unit) : base(log, unit)
        {
        }
        // GET: User
        public ActionResult Index()
        {
            _log.Info("Excecution of User Controller OK");
            return View(_unit.Users.GetList());
        }

        public PartialViewResult Create()
        {
            return PartialView("_Create", new User());
        }
        [HttpPost]
        public ActionResult Create(User user)
        {
            if (ModelState.IsValid)
            {
                _unit.Users.Insert(user);
                return RedirectToAction("Index");
            }
            return PartialView("_Create", user);
        }

        public PartialViewResult Edit(int id)
        {
            return PartialView("_Edit", _unit.Users.GetById(id));
        }

        [HttpPost]
        public ActionResult Edit(User user)
        {
            if (ModelState.IsValid)
            {
                _unit.Users.Update(user);
                return RedirectToAction("Index");
            }
            return PartialView("_Edit", user);
        }

        public ActionResult Delete(int id)
        {
            return PartialView("_Delete", _unit.Users.GetById(id));
        }

        [HttpPost]
        public ActionResult Delete(User user)
        {
            if (_unit.Users.Delete(user))
                return RedirectToAction("Index");
            return PartialView("_Delete", user);
        }

        public ActionResult Error()
        {
            throw new System.Exception("Test errorto validate actions");
        }
    }
}