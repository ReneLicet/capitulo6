USE [Northwind_Lite]
GO
CREATE TABLE [dbo].[User](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Email] [nvarchar](256) NULL,
	[FirstName] [nvarchar](256) NULL,
	[LastName] [nvarchar](256) NULL,
	[Password] [nvarchar](256) NULL,
	[Roles] [nvarchar](256) NULL
) ON [PRIMARY]
GO
INSERT [dbo].[User] ([Id], [Email], [FirstName], [LastName], [Password], [Roles]) 
VALUES (1, N'usuario@cibertec.com', N'Hugo', N'Parra', N'123456', N'Usuario')
GO
CREATE PROCEDURE [dbo].[ValidateUser]
@email varchar(100),
@password varchar(100)
AS
BEGIN
SELECT
	Id,
	Email,
	FirstName,
	LastName,
	Roles
FROM [dbo].[User]
WHERE Email = @email AND Password = @password
END
GO