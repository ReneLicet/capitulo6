﻿(function (user) {
    user.success = successReload;
    return user;
    function successReload() {
        cibertec.closeModal();
    }
}
)(window.user = window.user || {});